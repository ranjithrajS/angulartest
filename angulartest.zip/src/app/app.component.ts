
import {Component, Input} from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'angulartest';


constructor() { }

ranjith ="10";
name="ranjith"
ngOnInit() {
 
 
}
// example for let 
letmethod(){
  let kidage=10 // let will work inside the function 
  console.log(kidage)
}
thismethod(){
   alert(this.ranjith);
   this.ranjith; //decalare at top 
 }

//  3.function to return all the keys present in an object at any level 
object(){
let obj =  { a: 5, b: { c: { d: 10 } }}

let getKeys = (obj) =>{
  let arr = []
  JSON.stringify(obj,(key,value)=>{
    arr.push(key)
    return value
  })
  return arr.slice(1)
}
alert("Final Output ==>"+getKeys(obj))
console.log(getKeys(obj)) 

}

 reversestring() {
  // let str = (<HTMLInputElement>document.getElementById(name)).value;
  var str= document.getElementById('name').value;
  var newstring ="";
  for (var i=str.length-1;i>=0;i--)
{
   newstring +=str[i];
}
//  let final =(<HTMLInputElement>document.getElementById(output)).value =newstring;
 document.getElementById('output').value =newstring
}


// remove duplicate  array 
removeduplicate(){
var duplicate = [1,2,3,1,2,3,2,2,3,4,5,5,12,1,23,4,1];

var b = duplicate.reduce(function(finaloutputarray,prepareoutput,i,duplicate){
  if (finaloutputarray.indexOf(prepareoutput) == -1) finaloutputarray.push(prepareoutput);
  else finaloutputarray.push('')
  return finaloutputarray;

}, [])
alert("FinalOutput =>>"+b);
console.log("finaloutput =>"+b)
}

// remove duplicate  array 


length(){
  var finalresult =this.name.length
  alert("result=>"+finalresult)
}
}


